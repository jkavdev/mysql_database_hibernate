package br.com.jkavdev.mysql.world;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MysqlWorldApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MysqlWorldApiApplication.class, args);
	}

}
